//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 ##  A two-dimensional array of Strings is defined here:
 */

let lineArray = [ ["morning ", "chaos ", "squirrel "],
              ["comes ", "flails ", "leaves ", "flaunts "],
              ["again ", "anew ", "today "] ]

/*:
 
 ##  Two-dimensional array
 
 You can think of a two-dimensional array as an array or arrays.
 
 lineArray is an array of three elements.  Each element is itself, and array of Strings.  To access the first element of the array, we use the familiar notation:
 
    let firstElement = lineArray[0]
 
 */

/*:
 
 ##
 
 Assign the variable **secondElement** to the second element of lineArray below:  
 
 */

let secondElement = lineArray[0]

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(array:secondElement, fontSize: 18.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program to see the contents of variable secondElement and ensure that it is an array of Strings.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
