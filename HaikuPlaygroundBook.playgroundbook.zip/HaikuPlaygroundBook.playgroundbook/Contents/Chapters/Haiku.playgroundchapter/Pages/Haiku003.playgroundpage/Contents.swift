//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 
 ##  Concatenation of Strings.
 
Strings can be concatenated together to form another String value.  For example, the statement:
 
 */
let ozCharacters = "Dorothy" + ", " + "Toto" + ", " + "Scarecrow" + ", " + "Tin Man" + ", " + "Cowardly Lion" + ", " + "Wicked Witch"

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string: ozCharacters, fontSize: 12.0, fontName: "Zapfino", color: .black)
//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the playground now to see the contents of variable ozCharacters.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */



