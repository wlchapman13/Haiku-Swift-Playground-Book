//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 ##  Four arrays of Strings are defined:
 */

let lineArray1 = ["two ", "the ", "some ", "we ", "you "]
let lineArray2 = ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "]
let lineArray3 = ["frogs ", "souls ", "clowns ", "fruit "]
let lineArray4 = ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "]

/*:
 
 ##  Random function
 
 The following function will return a random integer between min (Int) and max (Int).
 
 For example, to create a random number between 1 and 10, use:
 
    let randomInteger = randomInt(min: 1, max: 10)
 
 */

func randomInt(min: Int, max: Int) -> Int {
    return min + Int(arc4random_uniform(UInt32(max - min + 1)))
}

/*:
 
 ##  Newline character
 
 You can insert a newline character (**\n**) between strings when you want the output to jump to the next line.
 
 Insert a newline between strings, instead of the current spaces, to create a list of randomly selected Strings below.
 
 */

let len1 = lineArray1.count-1
let len2 = lineArray2.count-1
let len3 = lineArray3.count-1
let len4 = lineArray4.count-1

var listOfRandomWords = "\(lineArray1[randomInt(min: 0, max: len1)]) \(lineArray2[randomInt(min: 0, max: len2)]) \(lineArray3[randomInt(min: 0, max: len3)]) \(lineArray4[randomInt(min: 0, max: len4)])"

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string:listOfRandomWords, fontSize: 24.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program several times now to see the contents of variable listOfRandomWords and ensure that it is being randomly generated.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
