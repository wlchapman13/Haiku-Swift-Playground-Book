//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code

import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code


/*:
 ##  The following code will create a random integer between 0 and 14 (not including 14).
 
 let aRandomNumber = arc4random_uniform(14)

 Edit the code below to create a list of 17 random numbers from 0 to 10 (not including 10):
 
 */

var stringOfRandoms = ""
var myRandom: Int
//#-editable-code Tap to enter code
for _ in 1 ... 3 {
    myRandom = Int(arc4random_uniform(92))
    //#-end-editable-code
    stringOfRandoms += "\(myRandom), "
}

print(stringOfRandoms)



//#-hidden-code
//  Create text
let text = Text(string: stringOfRandoms, fontSize: 18.0, fontName: "Zapfino", color: .black)
//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the playground now to see the contents of variable stringOfRandoms.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */


