//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//var aString = "" {
//willSet(newAstring) {
//    print("About to set totalSteps to \(newaString)")
//}
//    didSet {
//        if aString == "two"  {
//            print("Success - aString is \(aString) !!")
//        } else {
//            print("Failure - aString is \(aString) !!")
//        }
//    }
//}

//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 ##  An array of Strings is defined below:
 */

let lineArray = ["two ", "the ", "some ", "we "]

/*:
 
 ##  Accessing the first element
 
 Remember that the first element of an array has an index of 0.  To access the first element of the array of Strings (lineArray), we use:
 */

let aString = lineArray[0]
//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string: aString, fontSize: 32.0, fontName: "Zapfino", color: .black)

if aString == "two" {
    print("Success")
} else {
    print("Failure")
}
//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the playground now to see the contents of variable aString.
 */

/*:
 ##  Run the playground now to see the contents of variable aString.
 [**When finished, proceed to next page.**](@next)
 */


