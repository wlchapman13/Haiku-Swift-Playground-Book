//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 ##  Four arrays of Strings are defined below:
 */

let lineArray1 = ["two ", "the ", "some ", "we ", "you "]
let lineArray2 = ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "]
let lineArray3 = ["frogs ", "souls ", "clowns ", "fruit "]
let lineArray4 = ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "]

/*:
 
 ##  Number of items in an array
 
The number of items in an array can be found using the .count property for an array.  For example, the statement:
 
 let numberOfWordsInLine3 = lineArray3.count
 
 will assign the value 4 to numberOfWordsInLine3 since there are four String elements in this array.
 
 */

var phraseOfLastWords = "\(lineArray1[0]) \(lineArray2[0]) \(lineArray3[0]) \(lineArray4[0])"

/*:
 
 ##  Create a phrase composed of all the last words in the arrays
 
 The statement above creates a phrase composed of all the first words in each array.  Modify this statement so that the phrase is composed of all the **last** words in each array.  **Remember that array indices start counting at 0, so using lineArray1.count as an array index will attempt to access an element that is outside the defined array.**
 */

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string: phraseOfLastWords, fontSize: 24.0, fontName: "Zapfino", color: .black)
//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the playground now to see the contents of variable phraseOfLastWords.
 */

/*:
 [**When finished, proceed to next page.**](@next)
 */

