//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 ##  Anytime you find yourself naming a collection of variables something like: line1, line2, line3, ..., this is a good candidate to use an array.  What if each of line1, line2 and line3 are themselves 2-dimensional arrays?  Simple, you add a third dimension so that your new array is a 3-dimensional array.  It is, in effect, an 1-dimensional array or 2-dimensional arrays!
 
 Our 3D array is our new palette of words for our Haiku.
 */

let words = [ [ ["two ", "the ", "some ", "we ", "you "],
              ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "],
              ["frogs ", "souls ", "clowns ", "fruit "],
              ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "] ],

            [ ["beautiful ", "complicated ", "annoying ", "difficult ", "dangerous ", "popular ", "exciting ", "salacious "],
              ["butterfly ", "antelope ", "dinosaur ", "canary ", "polar bear ", "chimpanzee ", "octopus ", "lady bug ", "flamingo ", "centipede "],
              ["lands ", "stops ", "takes ", "tells ", "leaves ", "was ", "thinks ", "knows "] ],

            [ ["morning ", "chaos ", "squirrel ", "answer ", "mother ", "prestige "],
              ["comes ", "flails ", "leaves ", "flaunts ", "learns ", "snores "],
              ["again ", "anew ", "today ", "between ", "easy ", "later ", "always ", "slowly ", "often "] ] ]
/*:
 
 ##  Access an element from the 3-dimensional array words:
 
 Each of the three 2-dimensional arrays found in our outer array, 'words', is a palette of random words we will use to construct a line of our Haiku.
 
 First we will practice accessing individual elements in our 3D array.  In the second line words[1]..., the word "dangerous" can be found at:
 
    words[1][0][4]
 
 Change the code below so that the String variable 'arraysAre' is assigned the array element containing the word "easy " above.
 
 */


let arraysAre = words[1][0][4]

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string:arraysAre, fontSize: 32.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program to see the contents of variable arraysAre and ensure that you have chosen the correct array elements.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
