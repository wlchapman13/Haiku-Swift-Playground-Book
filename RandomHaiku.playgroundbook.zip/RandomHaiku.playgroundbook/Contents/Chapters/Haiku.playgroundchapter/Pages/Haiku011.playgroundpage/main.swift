//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:
##  A two-dimensional array of Strings is defined here:
*/

//#-editable-code Tap to enter code

let lineArray = [ ["", "morning ", "chaos ", "squirrel "],
              ["comes ", "flails ", "leaves ", "flaunts ", "jumps"],
              ["again ", "today "] ]

//#-end-editable-code

/*:
 
 ##  Accessing elements in a two-dimensional array
 
 Again, you can think of a two-dimensional array as an array of arrays.
 
 lineArray is an array of three elements.  Each element is itself, an array of Strings.  To assign a the value of the variable hidesNuts to be the third word of the first line, one needs to access the third element of the first array in lineArray:
 
    let hidesNuts = lineArray[0][2]     // hidesNuts will contain the String: "squirrel"
 
Replace the empty Strings below so that variable 'leaps' is assigned to the fifth element of the second array in lineArray;  the variable 'notTomorrow' is assigned the last word in the last array; and the variable 'firstWord' contains the second element of the first array of lineArray.
 */

//#-editable-code Tap to enter code

let leaps = lineArray[0][0]
let notTomorrow = lineArray[0][0]
let hereComesTheSun = lineArray[0][0]

let output = " leaps : \(leaps) \n notTomorrow : \(notTomorrow) \n hereComesTheSun : \(hereComesTheSun) "

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string:output, fontSize: 18.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program to see the contents of variable output and ensure that you have chosen the correct array elements.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
