//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:
##  A two-dimensional array of Strings is defined here:
*/

//#-editable-code Tap to enter code

let lineArray = [ ["morning ", "chaos ", "squirrel "], ["comes ", "flails ", "leaves ", "flaunts "], ["again ", "anew ", "today "] ]

//#-end-editable-code

/*:

##  Two-dimensional array

You can think of a two-dimensional array as an array of arrays.

lineArray is an array of three elements.  Each element is itself, an array of Strings.  To access the first element of the array, we use the familiar notation:

   let firstElement = lineArray[0]

##

Assign the variable **secondElement** to the second element of lineArray below:
// the 0..<lengthOfThirdArray expression translate to "a range from 0 up to BUT NOT INCLUDING lengthOfThirdArray"
 
*/

//#-editable-code Tap to enter code

let secondElement = lineArray[0]

//#-end-editable-code


//#-hidden-code

var testString = "zippy"
var buildString = "["
for i in 0 ..< secondElement.count - 1 {
    buildString += "\""
    buildString += secondElement[i]
    buildString += "\", "
}
if let lastElement = secondElement.last {
    buildString += lastElement
}
buildString += "]"

let text = Text(string:buildString, fontSize: 18.0, fontName: "Zapfino", color: .black)

// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program several times now to see the contents of variable listOfRandomWords and ensure that it is being randomly generated.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
