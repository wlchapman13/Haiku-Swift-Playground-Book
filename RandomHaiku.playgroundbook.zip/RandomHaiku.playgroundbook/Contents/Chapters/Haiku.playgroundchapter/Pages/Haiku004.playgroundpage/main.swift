//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:
 
 ##  Working with Strings.
 
We can use *string interpolation* to embed values of string variables inside another string.
 
 For example, the statement:

    let ozCharacters = "\(s0), \(s4)"
 
 will assign the value "Dorothy, Tin Man" to the variable ozCharacters.  Run the playground to see for yourself.
 
 Next, modify the code below to add the rest of the string variables (s1, s2, s4 and s5) so that the variable: ozCharacters has the value:
 
 "Dorothy, Toto, Scarecrow, Tin Man, Cowardly Lion, Wicked Witch"
 
 Be careful with your commas and spaces!
 
 */

//#-editable-code Tap to enter code

let s0 = "Dorothy"
let s1 = "Toto"
let s2 = "Scarecrow"
let s3 = "Tin Man"
let s4 = "Cowardly Lion"
let s5 = "Wicked Witch"

let ozCharacters = "\(s0), \(s3)"

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string: ozCharacters, fontSize: 12.0, fontName: "Zapfino", color: .black)
//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the playground now to see the contents of variable ozCharacters.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */



