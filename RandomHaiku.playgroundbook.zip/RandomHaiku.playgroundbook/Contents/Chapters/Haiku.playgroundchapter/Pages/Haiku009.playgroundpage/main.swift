//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:
##  Four arrays of Strings are defined:
*/

//#-editable-code Tap to enter code

let lineArray1 = ["two ", "the ", "some ", "we ", "you "]
let lineArray2 = ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "]
let lineArray3 = ["frogs ", "souls ", "clowns ", "fruit "]
let lineArray4 = ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "]

//#-end-editable-code

/*:
 
 ##  Random Word from Array
 
 The following Swift code will return a random word element from an array of Strings.
 
 */

//#-editable-code Tap to enter code

let lengthOfThirdArray = lineArray3.count
let randomIndexOfThirdArray = Int.random(in: 0..<lengthOfThirdArray)  // the 0..<lengthOfThirdArray expression translate to "a range from 0 up to BUT NOT INCLUDING lengthOfThirdArray"

//#-end-editable-code

/*:
 
 ##  Newline character
 
 You can insert a newline character (**\n**) between strings when you want the output to jump to the next line.
 
 Insert a newline between strings, instead of the current spaces, to create a list of randomly selected Strings below.
 
 */

//#-editable-code Tap to enter code

let len1 = lineArray1.count
let len2 = lineArray2.count
let len3 = lineArray3.count
let len4 = lineArray4.count

var listOfRandomWords = "\(lineArray1[Int.random(in: 0..<len1)]) \(lineArray2[Int.random(in: 0..<len2)]) \(lineArray3[Int.random(in: 0..<len3)]) \(lineArray4[Int.random(in: 0..<len4)])"

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string:listOfRandomWords, fontSize: 24.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program several times now to see the contents of variable listOfRandomWords and ensure that it is being randomly generated.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
