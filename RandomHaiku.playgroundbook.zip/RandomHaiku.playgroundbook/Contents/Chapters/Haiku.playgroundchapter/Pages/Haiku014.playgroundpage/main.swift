//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:
##  Three two-dimensional arrays of Strings are defined here.  Each array is a palette of words for our Haiku.
*/

//#-editable-code Tap to enter code

let line1 = [ ["two ", "the ", "some ", "we ", "you "],
              ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "],
              ["frogs ", "souls ", "clowns ", "fruit "],
              ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "] ]

let line2 = [ ["beautiful ", "complicated ", "annoying ", "difficult ", "dangerous ", "popular ", "exciting ", "salacious "],
              ["butterfly ", "antelope ", "dinosaur ", "canary ", "polar bear ", "chimpanzee ", "octopus ", "lady bug ", "flamingo ", "centipede "],
              ["lands ", "stops ", "takes ", "tells ", "leaves ", "was ", "thinks ", "knows "] ]

let line3 = [ ["morning ", "chaos ", "squirrel ", "answer ", "mother ", "prestige "],
              ["comes ", "flails ", "leaves ", "flaunts ", "learns ", "snores "],
              ["again ", "anew ", "today ", "between ", "easy ", "later ", "always ", "slowly ", "often "] ]

//#-end-editable-code

/*:
 
 ##  Create a line of verse for our Haiku:
 
 This time we will use another approach.  Use a for-loop to construct the line of verse...
 
 To construct this line of verse, we want a String created by concatenating all the fourth words from each of the four rows of line1.
 
 */

//#-editable-code Tap to enter code

var aLineOfPoem02 = ""
for i in 0 ..< line2.count {
    aLineOfPoem02 += line2[0][0]
}

//#-end-editable-code

//#-hidden-code
//  Create text
let text = Text(string:aLineOfPoem02, fontSize: 18.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program to see the contents of variable aLineOfPoem02 and ensure that you have chosen the correct array elements.
 */
/*:
 [**When finished, proceed to next page.**](@next)
 */
