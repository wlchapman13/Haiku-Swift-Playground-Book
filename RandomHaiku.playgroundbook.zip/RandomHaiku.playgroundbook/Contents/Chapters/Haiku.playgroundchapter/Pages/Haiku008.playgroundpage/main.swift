//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:
##  Four arrays of Strings are defined:
*/

//#-editable-code Tap to enter code

let lineArray1 = ["two ", "the ", "some ", "we ", "you "]
let lineArray2 = ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "]
let lineArray3 = ["frogs ", "souls ", "clowns ", "fruit "]
let lineArray4 = ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "]

//#-end-editable-code

/*:
 
 ##  Create a random phrase
 
 The Swift code below creates a phrase composed of all the last words in each array.  Modify this statement so that the phrase is composed of **random** words from each array.  Hint: remember Int.random(in: someNumber ... someOtherNumber) will produce a random number in the range someNumber to someOtherNumber.
 */

//#-editable-code Tap to enter code

let len1 = lineArray1.count-1
let len2 = lineArray2.count-1
let len3 = lineArray3.count-1
let len4 = lineArray4.count-1

var phraseOfRandomWords = "\(lineArray1[len1]) \(lineArray2[len2]) \(lineArray3[len3]) \(lineArray4[len4])"

//#-end-editable-code

//#-hidden-code
//  Create text
let text = Text(string:phraseOfRandomWords, fontSize: 24.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the playground now to see the contents of variable phraseOfRandomWords.
 */

/*:
 [**When finished, proceed to next page.**](@next)
 */
