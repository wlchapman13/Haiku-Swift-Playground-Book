//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-hidden-code
import Darwin

_setup()

// Put a background image in the playground
let parchmentImage = Image(name: "parchment.background")
parchmentImage.size.width *= 3.2
parchmentImage.size.height *= 9.0
// parchmentImage.center.y -= 0
parchmentImage.contentMode = .scaleAndStretchToFill

//#-end-hidden-code

/*:

##  FINAL CHALLENGE!:

You've got this!

*/

//#-editable-code Tap to enter code

let words = [ [ ["two ", "the ", "some ", "we ", "you "],
              ["solemn ", "friendly ", "silent ", "angry ", "viscious ", "greedy "],
              ["frogs ", "souls ", "clowns ", "fruit "],
              ["run ", "jump ", "fight ", "love ", "groan ", "speak ", "yell ", "kiss ", "eat ", "plan "] ],

            [ ["beautiful ", "complicated ", "annoying ", "difficult ", "dangerous ", "popular ", "exciting ", "salacious "],
              ["butterfly ", "antelope ", "dinosaur ", "canary ", "polar bear ", "chimpanzee ", "octopus ", "lady bug ", "flamingo ", "centipede "],
              ["lands ", "stops ", "takes ", "tells ", "leaves ", "was ", "thinks ", "knows "] ],

            [ ["morning ", "chaos ", "squirrel ", "answer ", "mother ", "prestige "],
              ["comes ", "flails ", "leaves ", "flaunts ", "learns ", "snores "],
              ["again ", "anew ", "today ", "between ", "easy ", "later ", "always ", "slowly ", "often "] ] ]

//#-end-editable-code

/*:
 
 ##  Write a program that creates random Haikus:
 
 Use a for-loop to construct each line of random verses below.
 
 To construct this Haiku, keep concatenating a random word from each array for each line until you reach the end of the line.  At that point, add a newline character (\n) to your String to ensure you start a new line.
 
 */

//#-editable-code Tap to enter code

var aRandomHaiku = ""
for i in 0 ..< words.count {  // i will be the index for each line of our Haiku
    //  each 2-dimensional palette of words for each line would be accessed with words[i]
    //  create a line of random verse here
    //  You may want to create another for-loop for each line of text.
    //  Finally, the length of the inner-most arrays will be accessed with something like words[i][j].length
    
    //  add a newline character to separate each line
    aRandomHaiku += "\n"
}

//#-end-editable-code
//#-hidden-code
//  Create text
let text = Text(string:aRandomHaiku, fontSize: 18.0, fontName: "Zapfino", color: .black)
// text.lineBreakMode = .ByWordWrapping // or NSLineBreakMode.ByWordWrapping
// text.numberOfLines = 0


//  text.center.y += 5
//#-end-hidden-code
/*:
 ##  Run the program to see the contents of variable aRandomHaiku and ensure that you have chosen the correct array elements.
 */
